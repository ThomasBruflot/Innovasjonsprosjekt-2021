# TMRh20 2014 - Newly Optimized Network Layer for nRF24L01(+) radios

Please see the full documentation at http://nRF24.github.io/RF24Network/

See http://nRF24.github.io/RF24/index.html for general RF24 configuration and setup
See http://nRF24.github.io/RF24/Linux.html and http://nRF24.github.io/RF24/RPi.html for Linux/RPi related config/setup
